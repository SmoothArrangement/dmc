<?php
class SinanInfo_Vehicles_Block_Vehicles extends Mage_Core_Block_Template
{
	public function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
}
?>