<?php
 
class SinanInfo_Vehicles_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }
    
    public function searchAction()
    {
        // Store selected bike (model | manufacturer | year)
        $request = Mage::app()->getRequest();
        $params = $request->getParams();
        $session = Mage::getModel('core/session');

        if (!empty($params['model']) && !empty($params['manufacturer']) && !empty($params['buildyear'])) {
            $session->setData('bike', $params);
        } else {
            $session->unsetData('bike');
        }
        $this->_redirect('vehicles');
    }

    public function resetAction()
    {
        $session = Mage::getModel('core/session');
        $session->unsetData('bike');
        $this->_redirect('vehicles');
    }
}
